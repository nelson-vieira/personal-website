import{default as t}from"../entry/_page.svelte.35a58827.js";export{t as component};
