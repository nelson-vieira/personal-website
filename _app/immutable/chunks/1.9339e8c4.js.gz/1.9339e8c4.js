import{default as t}from"../entry/error.svelte.8df92198.js";export{t as component};
